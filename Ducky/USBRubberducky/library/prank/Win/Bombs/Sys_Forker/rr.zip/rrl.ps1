while (1) { C:\Windows\System32\rr\rr.ps1; }
